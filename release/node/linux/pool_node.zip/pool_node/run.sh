#!/bin/bash
./node
