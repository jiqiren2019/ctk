package com.xinshang.test;

import com.xinshang.utils.HttpUtil;
import com.xinshang.utils.SignUtils;
import net.sf.json.JSONObject;
import org.bouncycastle.util.Strings;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class ApiTest {

    private final static String API_SERVER_IP = "https://n1.ctk.bz/";
    private final static String DM = "ctk";
    private final static String TOKEN = "token7";
    private final static String ACC = "0x5fe071ffc42eeb0535af2b7dd96cdf8a89b8265d";

    private final static String TEST_TXID = "53cf9e256e274b20821675bda8e50c3b22e26a429600714abb9e4afe319b739c";
    // 创建账号
    private final static String API_ACC = API_SERVER_IP + "acc";
    // 查询
    private final static String API_QRY = API_SERVER_IP + "qry";
    // 查询余额
    private final static String API_BAL = API_SERVER_IP + "bal";
    // 创建TX
    private final static String API_CRTTX = API_SERVER_IP + "crtTx";
    // 转账
    private final static String API_IVK = API_SERVER_IP + "ivk";
    // 交易查询
    private final static String API_TRADE = API_SERVER_IP + "trade";
    // token信息查询
    private final static String API_TKINFO = API_SERVER_IP + "tkinfo";
    // token挖矿收益列表
    private final static String API_TOKENAWDLIST = API_SERVER_IP + "tokenawdlist";
    // token 待领取挖矿收益
    private final static String API_AWARDPREVIEW = API_SERVER_IP + "awardpreview";
    // token 领取挖矿收益
    private final static String API_AWARD = API_SERVER_IP + "award";
    // 申请节点
    private final static String API_APPLYNODE = API_SERVER_IP + "applySpareNode";
    // 申请节点查询
    private final static String API_APPLYNODEINFO = API_SERVER_IP + "spareNodeSecret";
    // 申请节点状态查询
    private final static String API_APPLYNODESTATUS = API_SERVER_IP + "checkApplyStatus";


    @Test
    public void TestCreateAccount() {
        String result = HttpUtil.doGet(API_ACC + "?psw=" + "");
        System.out.println("创建账号：" + result);
        // Map params = new HashMap();
        // params.put("psw","123456");
        // result = HttpUtil.doPost(API_ACC,params);
        // System.out.println(result);
    }

    // 查询余额
    @Test
    public void TestQryBal() {
        String result = HttpUtil
                .doGet(API_QRY + "?cmd=qrybal&args=" + ACC + "&cc=" + TOKEN);
        System.out.println("查询余额：" + result);
    }

    // 批量查询余额
    @Test
    public void TestBatchQryBal() {
        Map map = new HashMap();
        map.put("arg","{\"cclist\":[{\"cc\":\"cedt\",\"addr\":\"0x5fe071ffc42eeb0535af2b7dd96cdf8a89b8265d\"},{\"cc\":\"token6\",\"addr\":\"0x5fe071ffc42eeb0535af2b7dd96cdf8a89b8265d\"}]}");
        String result = HttpUtil.doPost(API_BAL,map);
        System.out.println("批量查询余额：" + result);
    }

    // 获取交易tx
    @Test
    public void TestCrtTx() {
        String result = HttpUtil.doGet(API_CRTTX + "?cnt=2");
        System.out.println("创建tx:" + result);
    }

    // 创建转账请求
    @Test
    public void TestIvk() {

        // 获取交易TXID、NONCE
        String txnid = HttpUtil.doGet(API_CRTTX);
        JSONObject jsonObject = JSONObject.fromObject(txnid);
        String txid = jsonObject.getJSONObject("data").getString("txId");
        String nonce = jsonObject.getJSONObject("data").getString("nonce");

        // 转出账号
        String from = ACC;
        // 转入账号
        String to = "0xDeE2c9129ea4e5B41957ba3C0fae364B7FaEd245";
        // 转账金额
        String amo = "2";
        // keystore密码
        String pass = "foo";
        // 备注
        String remark = "remark";
        // 本地keystore文件
        String keystore = "src/com/xinshang/test/" + ACC + ".json";
        String msg = Strings.toLowerCase(txid + TOKEN + from + to + amo);
        // 签名体
        String sign = "";
        try {
            // 对消息体进行签名
            sign = SignUtils.signMsgByKeystoreFile(msg, keystore, pass);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }
        // 封装接口参数
        Map<String, String> params = new HashMap<String, String>();
        params.put("cc", TOKEN);
        params.put("from", from);
        params.put("to", to);
        params.put("amo", amo);
        params.put("sign", sign);
        params.put("remark", remark);
        params.put("txid", txid);
        params.put("nonce", nonce);
        String result = HttpUtil.doPost(API_IVK, params);
        System.out.println("转账：" + result);
    }

    // 查询交易列表
    @Test
    public void TestTradeHistory() {
        String result = HttpUtil.doGet(API_TRADE + "?method=history&cc=" + TOKEN
                + "&acc=" + ACC + "&page=1&number=10&status=0");
        System.out.println("交易记录：" + result);
    }

    // 查询交易详情
    @Test
    public void TestTradeTxrst() {

        String result = HttpUtil
                .doGet(API_TRADE + "?method=txrst&tx=c2c64abfb735a9969d3aadc66121f3c6ccd9964629ecbd4657033a1d6ce785f0" );
        System.out.println("交易详情：" + result);
    }

    // 查询token信息
    @Test
    public void TestTokenInfo() {
        String result = HttpUtil.doGet(API_TKINFO + "?cc=" + TOKEN);
        System.out.println("token详情：" + result);
    }


    // 查询token挖矿收益列表
    @Test
    public void TestTokenAwdList() {
        String result = HttpUtil.doGet(API_TOKENAWDLIST + "?token=" + TOKEN + "&acc=" + ACC);
        System.out.println("token详情：" + result);
    }

    // 查询token可领取挖矿收益
    @Test
    public void TestAwardpreview() {
        String result = HttpUtil.doGet(API_AWARDPREVIEW + "?token=" + TOKEN + "&acc=" + ACC);
        System.out.println("token详情：" + result);
    }


    // 查询token可领取挖矿收益
    @Test
    public void TestAward() {
        // 获取交易TXID、NONCE
        String txnid = HttpUtil.doGet(API_CRTTX);
        JSONObject jsonObject = JSONObject.fromObject(txnid);
        String txid = jsonObject.getJSONObject("data").getString("txId");
        String nonce = jsonObject.getJSONObject("data").getString("nonce");

        // keystore密码
        String pass = "foo";
        // 本地keystore文件
        String keystore = "src/com/xinshang/test/" + ACC + ".json";
        String msg = Strings.toLowerCase(txid + TOKEN + ACC);
        // 签名体
        String sign = "";
        try {
            // 对消息体进行签名
            sign = SignUtils.signMsgByKeystoreFile(msg, keystore, pass);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }
        // 封装接口参数
        Map<String, String> params = new HashMap<String, String>();
        params.put("txid", txid);
        params.put("nonce", nonce);
        params.put("acc", ACC);
        params.put("cc", TOKEN);
        params.put("sign", sign);
        String result = HttpUtil.doPost(API_AWARD, params);
        System.out.println("领取挖矿收益：" + result);
    }

    //测试申请节点接口
    @Test
    public void TestApplyNode() {
        // 获取交易TXID、NONCE
        String txnid = HttpUtil.doGet(API_CRTTX);
        JSONObject jsonObject = JSONObject.fromObject(txnid);
        String txid = jsonObject.getJSONObject("data").getString("txId");
        String nonce = jsonObject.getJSONObject("data").getString("nonce");

        //申请账号
        String from = ACC;
        //手续费
        String amo = "30000";
        // keystore密码
        String pass = "foo";
        // 备注
        // 本地keystore文件
        String keystore = "src/com/xinshang/test/" + ACC + ".json";
        String msg = Strings.toLowerCase(txid + from);
        // 签名体
        String sign = "";
        try {
            // 对消息体进行签名
            sign = SignUtils.signMsgByKeystoreFile(msg, keystore, pass);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }
        // 封装接口参数
        Map<String, String> params = new HashMap<String, String>();
        params.put("acc", from);
        params.put("nodetype", "1"); //申请节点类型 1 超级矿池 0 备用节点
        params.put("amount", amo);
        params.put("sign", sign);
        params.put("txid", txid);
        params.put("nonce", nonce);
        String result = HttpUtil.doPost(API_APPLYNODE, params);
        System.out.println("申请节点：" + result);
    }

    //测试申请节点查询接口信息
    @Test
    public void TestApplyNodeInfo() {
        // 获取交易TXID、NONCE
        String txnid = HttpUtil.doGet(API_CRTTX);
        JSONObject jsonObject = JSONObject.fromObject(txnid);
        String txid = jsonObject.getJSONObject("data").getString("txId");
        String nonce = jsonObject.getJSONObject("data").getString("nonce");

        //申请账号
        String from = ACC;
        //手续费
        String amo = "30000";
        // keystore密码
        String pass = "foo";
        // 备注
        // 本地keystore文件
        String keystore = "src/com/xinshang/test/" + ACC + ".json";
        String msg = Strings.toLowerCase(txid + from);
        // 签名体
        String sign = "";
        try {
            // 对消息体进行签名
            sign = SignUtils.signMsgByKeystoreFile(msg, keystore, pass);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }
        // 封装接口参数
        Map<String, String> params = new HashMap<String, String>();
        params.put("acc", from);
        params.put("sign", sign);
        params.put("txid", txid);
        String result = HttpUtil.doPost(API_APPLYNODEINFO, params);
        System.out.println("查询申请节点信息：" + result);
    }

    //测试申请节点状态查询接口
    @Test
    public void TestApplyNodeStatus() {
        //申请账号
        String from = ACC;
        // 封装接口参数
        Map<String, String> params = new HashMap<String, String>();
        params.put("acc", from);
        String result = HttpUtil.doPost(API_APPLYNODESTATUS, params);
        System.out.println("查询申请节点状态：" + result);
    }


}
