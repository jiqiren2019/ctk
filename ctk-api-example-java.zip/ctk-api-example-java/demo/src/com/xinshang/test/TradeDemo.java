package com.xinshang.test;

import com.xinshang.utils.HttpUtil;
import com.xinshang.utils.SignUtils;
import jdk.nashorn.internal.parser.Token;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.bouncycastle.util.Strings;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class TradeDemo {

    // private final static String API_SERVER_IP = "https://n5.m.cc/";
    private final static String API_SERVER_IP = "http://180.100.214.201:8888/";
    // 创建TX
    private final static String API_CRTTX = API_SERVER_IP + "crtTx";
    // 转账
    private final static String API_IVK = API_SERVER_IP + "ivk";
    // 交易查询
    private final static String API_TRADE = API_SERVER_IP + "trade";

    private final static String ACC = "0x5fe071ffc42eeb0535af2b7dd96cdf8a89b8265d";

    private final static String HISTORY_ACC = "0x8fc2e72e0532d50addd67ca3bf120f645d9f9239";

    private final static String DM = "dm";

    public static void main(String[] args) {
        TradeDemo demo = new TradeDemo();
        //转账测试demo
        //可用于提币功能
        try {
          //  demo.tradeTest();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //检查平台系统账号的交易记录，监听新的交易，捕获新交易后，处理具体业务逻辑
        //可用于充币功能
        demo.checkSystemAccTradeHistory();
    }


    /**
     * 所有涉及到金额变动的接口，第一步都需要提前调用crtTx接口获取交易txid、随机数nonce。
     *
     * @throws Exception
     */
    public void tradeTest() throws Exception {

        // 获取交易TXID、NONCE(该接口支持批量获取(一次性最多100条)。可批量获取后本地缓存，减少接口调用，节省转账调用时间)
        String txnid = HttpUtil.doGet(API_CRTTX);
        System.out.println("获取交易TX接口返回结果：");
        System.out.println(txnid);
        JSONObject jsonObject = JSONObject.fromObject(txnid);
        String txid = jsonObject.getJSONObject("data").getString("txId");
        String nonce = jsonObject.getJSONObject("data").getString("nonce");

        // 转出账号
        String from = ACC;
        // 转入账号
        String to = "0xDeE2c9129ea4e5B41957ba3C0fae364B7FaEd245";
        // 转账金额
        String amo = "2";
        // keystore密码
        String pass = "foo";

        // 转账币种
        String TOKEN = "dm";
        // 备注
        String remark = "remark";
        // 本地keystore文件
        String keystore = "src/com/xinshang/test/" + ACC + ".json";
        // 转账待签名消息体
        String msg = Strings.toLowerCase(txid + TOKEN + from + to + amo);
        // 签名体
        String sign = "";
        try {
            // 对消息体进行签名
            sign = SignUtils.signMsgByKeystoreFile(msg, keystore, pass);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        // 封装接口参数
        Map<String, String> params = new HashMap<String, String>();
        params.put("cc", TOKEN);
        params.put("from", from);
        params.put("to", to);
        params.put("amo", amo);
        params.put("sign", sign);
        params.put("remark", remark);
        params.put("txid", txid);
        params.put("nonce", nonce);
        String result = HttpUtil.doPost(API_IVK, params);

        System.out.println("转账交易接口结果：");
        System.out.println(result);

        if (StringUtils.isBlank(result)) {
            throw new Exception("转账交易异常！");
        }
        JSONObject json = new JSONObject();
        try {
            json = JSONObject.fromObject(result);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

        String status = json.getString("status");
        String info = json.getString("info");
        String data = json.getString("data");

        if ("1".equals(status) && "success".equals(info)) {
            System.out.println("转账交易成功，交易ID：" + data);
        } else if ("1".equals(status) && "processing".equals(info)) {
            // 转账交易处理中
            String rtn = checkTransferStatus(data);
            System.out.println("rtn:" + rtn);
        } else {
            System.out.println("接口返回错误：" + info);
        }
    }


    //检查交易状态
    public String checkTransferStatus(String txid) {
        // run in a second
        final long timeInterval = 1000;
        class Runner implements Runnable {
            private String rtnStr = "";

            public String getRtnStr() {
                return this.rtnStr;
            }

            public void setRtnStr(String rtn) {
                this.rtnStr = rtn;
            }

            public void run() {
                while (true) {
                    String result = HttpUtil
                            .doGet(API_TRADE + "?method=txrst&tx=" + txid);
                    System.out.println("查询交易详情结果：");
                    System.out.println(result);
                    JSONObject json = new JSONObject();
                    try {
                        json = JSONObject.fromObject(result);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    if (json.getJSONObject("data").has("txId")) {
                        this.setRtnStr("交易转账已成功到账！");
                        break;
                    } else if (json.getString("info") == "invalidTxid") {
                        this.setRtnStr("交易转账失败！invalidTxid");
                        break;
                    }
                    try {
                        Thread.sleep(timeInterval);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        Runner r = new Runner();
        Thread thread = new Thread(r);
        thread.start();

        //等待线程返回交易查询结果
        while (r.getRtnStr().isEmpty()) {
            try {
                Thread.sleep(timeInterval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return r.getRtnStr();
    }


    //定时查询系统对公账号交易记录
    public void checkSystemAccTradeHistory() {

        // run in a second
        final long timeInterval = 10000;

        class Runner implements Runnable {
            // 查询交易记录初始页
            int page = 1;
            BigDecimal lastMaxBlockNum = BigDecimal.valueOf(0);
            //记录本次处理到的最大块号，因交易记录倒序，所以是while循环的第一条记录
            String currentMaxBlockNumStr = "";
            //最大支持100条记录
            int pageSize = 100;
            //转出1，转入2，失败3。因为测试账号 0x8fc2e72e0532d50addd67ca3bf120f645d9f9239 暂无足够转入交易记录，所以切换为转出交易记录
            int stat = 1;

            public void run() {
                while (true) {
                    // 查询交易记录接口地址
                    String url = API_TRADE + "?method=history&cc=" + DM + "&acc=" + HISTORY_ACC + "&page=" + page + "&status=" + stat + "&number=" + pageSize;
                    System.out.println(url);
                    String result = HttpUtil.doGet(url);
                    JSONObject json = new JSONObject();
                    try {
                        json = JSONObject.fromObject(result);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    JSONArray jsonArray = json.getJSONArray("data");
                    if (jsonArray.size() == 0) {
                        break;
                    }
                    if (page == 1) {
                        currentMaxBlockNumStr = JSONObject.fromObject(jsonArray.get(0)).getString("blockNum");
                    }
                    if (jsonArray.size() == pageSize) {
                        page++;
                    } else {
                        page = 1;
                    }
                    for (int i = 0; i < jsonArray.size(); i++) {
                        JSONObject jsObj = JSONObject.fromObject(jsonArray.get(i));
                        //当前处理的块
                        BigDecimal bd = new BigDecimal(jsObj.getString("blockNum"));
                        //如果是最后一页最后一条数据，或者当前块号已小于等于上次处理的最大块号，则重新更新上次处理最大块号数值，并跳出循环。重新检查交易记录
                        if (bd.compareTo(lastMaxBlockNum) <= 0 || ((i == jsonArray.size() - 1) && jsonArray.size() < pageSize)) {
                            lastMaxBlockNum = new BigDecimal(currentMaxBlockNumStr);
                            page = 1;
                            break;
                        }
                        System.out.println("当前处理到的块号：" + bd + "   page:" + (page - 1) + "  lastMaxBlockNum： " + lastMaxBlockNum);
                        //此处写平台到账后的业务处理
                        System.out.println(jsObj.toString());


                    }
                    try {
                        Thread.sleep(timeInterval);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        Runner r = new Runner();
        Thread thread = new Thread(r);
        thread.start();

        return;
    }


}
