package com.xinshang.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.web3j.crypto.*;
import org.web3j.utils.Numeric;

import java.io.*;

public class SignUtils {

    //  私钥字符串签名消息体
    public static String signMsgByPrivateKey(byte[] msg, String privateKey) {
        ECKeyPair pair = ECKeyPair.create(Numeric.hexStringToByteArray(privateKey));
        Sign.SignatureData signatureData = Sign.signMessage(Numeric.toHexStringNoPrefix(msg).getBytes(), pair);
        byte[] bt3 = new byte[1];
        int head = signatureData.getV() & 0xFF;
        int recId = head - 27;
        bt3[0] = (byte) recId;

        byte[] byte_3 = new byte[signatureData.getR().length + signatureData.getS().length + 1];
        System.arraycopy(signatureData.getR(), 0, byte_3, 0, signatureData.getR().length);
        System.arraycopy(signatureData.getS(), 0, byte_3, signatureData.getR().length, signatureData.getS().length);
        System.arraycopy(bt3, 0, byte_3, signatureData.getS().length + signatureData.getR().length, 1);
        return Numeric.toHexString(byte_3).substring(2);
    }

    //通过ECKeyPair钱明星消息体
    public static String signMsgByKeyPair(byte[] msg, ECKeyPair pair) {
        Sign.SignatureData signatureData = Sign.signMessage(Numeric.toHexStringNoPrefix(msg).getBytes(), pair);
        byte[] bt3 = new byte[1];
        int head = signatureData.getV() & 0xFF;
        int recId = head - 27;
        bt3[0] = (byte) recId;

        byte[] byte_3 = new byte[signatureData.getR().length + signatureData.getS().length + 1];
        System.arraycopy(signatureData.getR(), 0, byte_3, 0, signatureData.getR().length);
        System.arraycopy(signatureData.getS(), 0, byte_3, signatureData.getR().length, signatureData.getS().length);
        System.arraycopy(bt3, 0, byte_3, signatureData.getS().length + signatureData.getR().length, 1);
        return Numeric.toHexString(byte_3).substring(2);
    }


    // 通过keystore签名消息体
    public static String signMsgByKeystoreFile(String msg, String path, String pass) throws Exception {
        String keyStore = readKeystoreFile(path);
        WalletFile walletFile = null;
        try {
            walletFile = load(keyStore);
        } catch (IOException e) {
            e.printStackTrace();
        }
        ECKeyPair ecKeyPair = null;
        try {
            ecKeyPair = Wallet.decrypt(pass, walletFile);
        } catch (Exception e) {
            throw new Exception("密码错误~");
        }
        return signMsgByKeyPair(msg.getBytes(), ecKeyPair);
    }


    // keystore内容转换成walletFile
    private static WalletFile load(String source) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(source, WalletFile.class);
    }


    //加载可以store文件
    public static String readKeystoreFile(String temPath) {
        File file = new File(temPath);
        StringBuilder stringBuilder = new StringBuilder();
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file), "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String lineStr = null;
            while ((lineStr = bufferedReader.readLine()) != null) {
                stringBuilder.append(lineStr);
            }
            bufferedReader.close();
            inputStreamReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }
}
