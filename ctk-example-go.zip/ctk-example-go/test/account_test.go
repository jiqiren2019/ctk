package main

import (
	"fmt"
	"strings"
	"os"
	"path/filepath"
	"io/ioutil"
	"testing"
	"ctk-example-go/apiclient"
)


//测试创建账号
func TestCreate(t *testing.T){
	var path = "D:\\go\\src\\daima-example"
	account,keystore,err := apiclient.AddAccount("123456")
	if err != nil{
		fmt.Println(err)
	}else{

		var keyFileName = strings.ToLower(account) + ".json"
		pathFile := path + "\\" + keyFileName
		if err := os.MkdirAll(filepath.Dir(pathFile), 0700); err != nil {
			fmt.Println("无法创建目录:"+ filepath.Dir(pathFile))
			return
		}
		if err := ioutil.WriteFile(pathFile, []byte(keystore), 0600); err != nil {
			fmt.Println("无法写入内容到:"+ pathFile)
			return
		}

		fmt.Println("账号:",account,"创建成功")
		fmt.Println("keystory保存位置:",pathFile)
	}
}