package main

import (
	"fmt"
	"time"
	"testing"
	"ctk-example-go/apiclient"
)


/**
测试转账接口
 */
func TestTransfer(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var from = "0x8fc2e72e0532d50addd67ca3bf120f645d9f9000"
	var to = "0x5452d7f7f888a88fc3e8b77b19254f6f4901eb22"
	var number = "1"
	var token = "token6"
	var TransferClass = apiclient.TransferClass{}
	var keyFile string = "D:\\go\\src\\daima\\util\\account\\0x8fc2e72e0532d50addd67ca3bf120f645d9f9000.json"
	var password = "123456"
	//获取交易id
	txData,err := apiclient.GetTxid() ; if err != nil{
		fmt.Println("获取交易id失败:", err)
		return
	}

	//进行转账处理
	status,txid, info := TransferClass.Transfer(txData.Data,from, to, number,token, keyFile, password)
	if status != 1 {
		fmt.Println("error:", info)
		return
	}

	//每隔1秒查询一次执行结果直到返回成功或失败
	for{
		data, err := TransferClass.Find(txid)
		if err != nil {
			fmt.Println("error:", err)
			break
		} else {
			//如果成功(status=1)或失败(status=2)则停止查询
			if data.Status == "1" || data.Status == "2" {
				fmt.Println("-------------------------------------------------")
				fmt.Println("交易ID		",data.Txid)
				fmt.Println("交易时间	",data.Time)
				fmt.Println("所在区块号	",data.BlockNum)
				fmt.Println("交易类型	",data.GetTypeText())
				fmt.Println("交易状态	",data.GetStatusText())
				fmt.Println("转出账号	",data.Out)
				fmt.Println("转入账号	",data.In)
				fmt.Println("交易数量	",data.Amount)
				fmt.Println("手续费		",data.Fee)
				fmt.Println("合计费用	",data.Sum)
				fmt.Println("Token		",data.Token)
				fmt.Println("交易备注	",data.Remake)
				break;
			}
		}
		time.Sleep(time.Second*1)
	}

}

/**
测试转账结果查询接口
 */
func TestFind(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var txid1 = "a1f11758be95d2eb9408c8c62a0c4276b220da82f6a587bf97e597f080febfae"
	var TransferClass = apiclient.TransferClass{}
	//转账结果查询
	data, err := TransferClass.Find(txid1)
	if err != nil {
		fmt.Println("error:", err)
	} else {
		fmt.Println("-------------------------------------------------")
		fmt.Println("交易ID		",data.Txid)
		fmt.Println("交易时间	",data.Time)
		fmt.Println("所在区块号	",data.BlockNum)
		fmt.Println("交易类型	",data.GetTypeText())
		fmt.Println("交易状态	",data.GetStatusText())
		fmt.Println("转出账号	",data.Out)
		fmt.Println("转入账号	",data.In)
		fmt.Println("交易数量	",data.Amount)
		fmt.Println("手续费		",data.Fee)
		fmt.Println("合计费用	",data.Sum)
		fmt.Println("Token		",data.Token)
		fmt.Println("交易备注	",data.Remake)

		fmt.Println("司法鉴定编号	",data.AuthoritySign)
	}
}

/**
测试转账列表查询接口
 */
func TestTransferList(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var token = "ctk"
	var account = "0x2fa06b515f5b9d1c0bB246263F53cD2ef21df30c"
	var page = "1"
	var number ="100"
	var TransferClass = apiclient.TransferClass{}
	//转账结果查询
	list, err := TransferClass.TransferList(token,account,page,number)
	if err != nil {
		fmt.Println("error:", err)
	} else {
		for i:=0;i<len(list);i++{
			data := list[i]
			fmt.Println("-------------------------------------------------")
			fmt.Println("交易ID		",data.Txid)
			fmt.Println("交易时间	",data.Time)
			fmt.Println("所在区块号	",data.BlockNum)
			fmt.Println("交易类型	",data.GetTypeText())
			fmt.Println("交易状态	",data.GetStatusText())
			fmt.Println("转出账号	",data.Out)
			fmt.Println("转入账号	",data.In)
			fmt.Println("交易数量	",data.Amount)
			fmt.Println("手续费		",data.Fee)
			fmt.Println("合计费用	",data.Sum)
			fmt.Println("Token		",data.Token)
			fmt.Println("交易备注	",data.Remake)

			fmt.Println("司法鉴定编号	",data.AuthoritySign)
		}
	}
}