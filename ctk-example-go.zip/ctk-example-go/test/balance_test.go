package main

import (
	"fmt"
	"testing"
	"ctk-example-go/apiclient"
)



//测试普通余额查询
func TestFind1(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var token = "mtok1"
	var account = "0x7981c1249256aa71bcC880F9BA7233f344ef6027"
	balance,err := apiclient.Balance(token,account)

	if err != nil {
		t.Error("error:", err)
	}else{
		fmt.Println("账号:",account,"Token:",token,"余额:",balance)
	}
}

//测试普通余额查询
func TestFind2(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var token = "ctk"
	var account = "0x7981c1249256aa71bcC880F9BA7233f344ef6027"
	balance,err := apiclient.Balance(token,account)

	if err != nil {
		t.Error("error:", err)
	}else{
		fmt.Println("账号:",account,"Token:",token,"余额:",balance)
	}
}

//测试批量余额查询
func TestBatFind(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var tokenList = []string{"ctk","ctk","mtok1"}
	var accountList = []string{"0x7981c1249256aa71bcC880F9BA7233f344ef6027","0x8fc2e72e0532d50addd67ca3bf120f645d9f9239","0x7981c1249256aa71bcC880F9BA7233f344ef6027"}
	keylist,err := apiclient.BatBalance(tokenList,accountList)
	if err != nil {
		fmt.Println("error:", err)
	}else{
		var i = 0
		for _,v := range keylist{
			fmt.Println("Token:[",tokenList[i],"],账号:[",accountList[i],"]余额:[",v,"]")
			i++
		}
	}
}