package main

import (
	"fmt"
	"testing"
	"ctk-example-go/apiclient"
)


/**
测试获取token信息的接口
 */
func TestInfo(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var tokenName = "mtok1"
	var Token = apiclient.Token{}

	tokenInfo,err := Token.Find(tokenName)
	if err != nil {
		fmt.Println("error:", err)
		return
	}
	fmt.Println("token名称		",tokenInfo.Title)
	fmt.Println("token英文简写	",tokenInfo.Name)
	fmt.Println("token发布时间	",tokenInfo.Date)
	fmt.Println("token资产总量	",tokenInfo.Total)
	fmt.Println("token资产预挖	",tokenInfo.Award)
	fmt.Println("tokenLogo	",tokenInfo.Logo)
	fmt.Println("token创始人	",tokenInfo.Creator)
	fmt.Println("token资产自动挖矿速度",tokenInfo.Mineral)
	fmt.Println("token小数点精度	",tokenInfo.Decimal)
	fmt.Println("token官网		",tokenInfo.Url)
}

/**
测试预览token挖矿收益
 */
func TestAwardReview(t *testing.T){
	apiclient.ServerIp = "https://n1.ctk.bz"
	var tokenName = "mtok1"
	var account = "0x7981c1249256aa71bcC880F9BA7233f344ef6027"

	var TokenMiner = apiclient.TokenMiner{}

	award,err := TokenMiner.AwardReview(tokenName,account)
	if err != nil{
		fmt.Println("错误:",err)
		return
	}else{
		fmt.Println("可领取的挖矿收益:",award)
	}
}

/**
测试领取token挖矿收益
 */
func TestAwardGet(t *testing.T){

	apiclient.ServerIp = "https://n1.ctk.bz"
	var tokenName = "mtok1"
	var account = "0x7981c1249256aa71bcC880F9BA7233f344ef6027"
	var keyFile string = "D:\\daimablockchain\\account\\yuetao\\0x7981c1249256aa71bcC880F9BA7233f344ef6027.json"
	var passwd = "12345678"

	var TokenMiner = apiclient.TokenMiner{}
	status,err := TokenMiner.AwardGet(tokenName,account,keyFile,passwd)
	if status != 1{
		fmt.Println(err)
		return
	}else{
		fmt.Println("领取挖矿收益成功")
	}
}

/**
测试挖矿收益列表
 */
 func TestAwardList(t *testing.T){

	 apiclient.ServerIp = "https://n1.ctk.bz"
	 var tokenName = "mtok1"
	 var account = "0x7981c1249256aa71bcC880F9BA7233f344ef6027"

	 var TokenMiner = apiclient.TokenMiner{}

	 //挖矿记录查询
	 list, err := TokenMiner.AwardList(tokenName,account)
	 if err != nil {
		 fmt.Println("error:", err)
	 } else {
		 fmt.Println("账号:		",account)
		 fmt.Println("Token	:	",tokenName)
		 for i:=0;i<len(list);i++{
			 data := list[i]
			 fmt.Println("-------------------------------------------------")
			 fmt.Println("挖矿收益:	",data.Money)
			 fmt.Println("挖矿时间:	",data.Date)
		 }
	 }
 }