package main

import (
	"ctk-example-go/apiclient"
	"testing"
	"fmt"
	"io/ioutil"
	"strings"
	"encoding/hex"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"net/http"
)

/**
申请节点接口
 */
func TestApplySpareNode(t *testing.T) {
	apiclient.ServerIp = "https://n1.ctk.bz"

	var from = "0x8fc2e72e0532d50addd67ca3bf120f645d9f9000"
	var TransferClass = apiclient.TransferClass{}
	var keyFile string = "D:\\go\\src\\daima\\util\\account\\0x8fc2e72e0532d50addd67ca3bf120f645d9f9000.json"
	var password = "123456"
	//获取交易id
	txData, err := apiclient.GetTxid()
	if err != nil {
		fmt.Println("获取交易id失败:", err)
		return
	}
	fmt.Println("txid:",txData.Data.TxId)
	fmt.Println("nonce:",txData.Data.Nonce)
	//return
	to:="0xa867b34ff1b5c80a7658fcbd1012e568c66af10a"
	amount:="300000" //费用需要依据共进比例计算
	token:="ctk"
	nodeStatus:="1" //申请节点类型(1 矿池 0 备用节点)
	status, txid, info := TransferClass.ApplySpareNode(txData.Data, from, keyFile, password,to,amount,token,nodeStatus)
	if status != 1 {
		fmt.Println("error:", info)
		return
	}
	fmt.Println("申请节点的txid",txid)
}

/**
申请节点查询接口
*/
func TestQuerySpareNode(t *testing.T) {
	apiclient.ServerIp = "https://n1.ctk.bz"
	var from = "0x8fc2e72e0532d50addd67ca3bf120f645d9f9000"
	var keyFile string = "D:\\go\\src\\daima\\util\\account\\0x8fc2e72e0532d50addd67ca3bf120f645d9f9000.json"
	var password = "123456"
	//获取交易id
	txData, err := apiclient.GetTxid()
	if err != nil {
		fmt.Println("获取交易id失败:", err)
		return
	}
	//解析钱包json
	keyjson, err := ioutil.ReadFile(keyFile)
	if err != nil {
		fmt.Println("无法解析钱包json",err)
		return
	}
	//获取私钥
	key, err := keystore.DecryptKey(keyjson, password)
	if err != nil {
		fmt.Println("无法获取私钥",err)
		return
	}
	fmt.Println("txid:",txData.Data.TxId)
	fmt.Println("nonce:",txData.Data.Nonce)
	msgBody := strings.ToLower(txData.Data.TxId + from )
	msgBody = hex.EncodeToString([]byte( msgBody ))
	fmt.Println("消息",msgBody)
	sign := apiclient.Sign(msgBody, key)
	fmt.Println("签名",sign)
	url := apiclient.ServerIp + "/spareNodeSecret"+ `?acc=` + from+"&lang=en"+"&txid=1d6256f4db06b5804729a82d7552058531a28d100eb2768364a586b4b242b8a6&sign=a70a0268bbfe64c71a78ebe091311f4f61d7c71b9c53631160085d9d6e192a43084f39aa0e7e51833a38dd2ccfccc3d1406c7fd8ba327f80a2edde5285f9a15c00"
	fmt.Println(url)
	resp, err := http.Get(url)
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}
	fmt.Println("~~~~~~applyNodeDetail~~~~~~~~~", string(body))
}

/**
申请节点状态查询接口
*/
func TestQuerySpareNodeStatus(t *testing.T) {
	apiclient.ServerIp = "https://n1.ctk.bz"
	var from = "0x8fc2e72e0532d50addd67ca3bf120f645d9f9000"
	url := apiclient.ServerIp + "/checkApplyStatus"+ `?acc=` + from+"&lang=en"
	fmt.Println(url)
	resp, err := http.Get(url)
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}
	fmt.Println("~~~~~~checkApplyStatus~~~~~~~~~", string(body))
}