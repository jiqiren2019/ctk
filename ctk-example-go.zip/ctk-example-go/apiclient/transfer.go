package apiclient

import (
	//"errors"
	"fmt"
	"io/ioutil"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"encoding/hex"
	strings "strings"
	"errors"
	"github.com/bitly/go-simplejson"
	"strconv"
)

//转账接口
type TransferJsonData struct{
	Status string
	Info string
	Data string
}

//交易详情
type TransferDetail struct{
	Out string
	In string
	Txid string
	Token string
	Fee string
	Amount string
	Time string
	BlockNum string
	Status string
	Remake string
	Error string
	Type string
	Sum string
	AuthoritySign string
}

//转账类
type TransferClass struct{

}


//返回交易类型的文本描述
func (t *TransferDetail) GetTypeText() (string){
	if t.Type == "0" {
		return "转账"
	}else if t.Type == "1"{
		return "发布token"
	}else{
		return "未知状态:"+ t.Type
	}
}

//返回交易状态的文本描述
func (t *TransferDetail) GetStatusText() (string){
	if t.Status == "0" {
		return "等待处理中"
	}else if t.Status == "1"{
		return "成功"
	}else if t.Status == "2"{
		return "失败"
	}else{
		return "未知状态:"+ t.Status
	}
}

/**
转账
 */
func (t *TransferClass) Transfer(tx TxIdData,from,to,num ,token ,keyFile ,passwd string) (int,string,string){

	//解析钱包json
	keyjson, err := ioutil.ReadFile(keyFile)
	if err != nil {
		return 0,"","无法解析钱包json"
	}
	//获取私钥
	key, err := keystore.DecryptKey(keyjson, passwd)
	if err != nil {
		return 0,"","无法获取私钥"
	}

	status,info := t.doTransfer(from,to,num,token,tx,key)

	return status,tx.TxId,info
}


func (t *TransferClass) doTransfer(from ,to ,num ,token string,tx TxIdData,key *keystore.Key) (int,string){
	msgBody :=  strings.ToLower(tx.TxId + token + from + to + num)
	msgBody = hex.EncodeToString([]byte( msgBody ))
	sign := Sign(msgBody,key)
	url := ServerIp + "/ivk"
	prama := "lang=zh-cn&from=" + from + "&to=" + to + "&amo=" + num +  "&cc=" + token + "&sign=" + sign + "&txid=" + tx.TxId + "&nonce=" + tx.Nonce

	jsonStr,err := SendRequest(url, prama)

	fmt.Println("jsonStr:",jsonStr)

	if err != nil {
		return 0,err.Error()
	}

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return 0,"NewJson:" + err.Error()
	}

	status,err := jsonData.Get("status").String()

	if err != nil {
		return 0,"Json.Get status:" + err.Error()
	}

	info,err := jsonData.Get("info").String()

	if err != nil {
		return 0,"Json.Get info:" + err.Error()
	}

	statusInt,err := strconv.Atoi(status)
	if err != nil {
		return 0,"strconv.Atoi status:" + err.Error()
	}
	return statusInt,info
}


//交易列表详情
type TransferListDetail struct{
	Out string
	In string
	Txid string
	Token string
	Fee string
	Amount string
	Time string
	BlockNum string
	Remark string
	Sum string
	Flag string
	Type string
	MinerIncome string
}


/*
* 交易详情查询
 */
func (t *TransferClass) Find(txid string) (TransferDetail,error){
	var detail TransferDetail = TransferDetail{}
	url := ServerIp + "/trade"
	prama := "method=txrst&tx=" + txid

	jsonStr,err := SendRequest(url, prama)

	if err != nil {
		return detail,errors.New(err.Error())
	}

	fmt.Println(jsonStr)
	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return detail,errors.New(err.Error())
	}

	status,err := jsonData.Get("status").String()

	if err != nil {
		return detail,errors.New("Json.Get status:" + err.Error())
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return detail,errors.New("Json.Get info:" + info)
	}else{
		data := jsonData.Get("data")
		detail.Amount,_ = data.Get("amount").String()
		detail.BlockNum,_ = data.Get("blockNum").String()
		detail.Error,_ = data.Get("error").String()
		detail.Fee,_ = data.Get("fee").String()
		detail.Remake,_ = data.Get("remark").String()
		detail.Type,_ = data.Get("type").String()
		detail.Status,_ = data.Get("status").String()
		detail.Txid,_ = data.Get("txId").String()
		detail.In,_ = data.Get("in").String()
		detail.Out,_ = data.Get("out").String()
		detail.Sum,_ = data.Get("sum").String()
		detail.Time,_ = data.Get("time").String()
		detail.Token,_ = data.Get("token").String()
		detail.AuthoritySign,_ = data.Get("authority_sign").String()
		return detail,nil
	}
}

/**
获取账号的交易列表
 */
func (t *TransferClass) TransferList(token,account ,page ,number string) ([]TransferDetail,error){
	var list []TransferDetail
	url := ServerIp + "/trade"
	prama := "method=history&cc="+token+"&acc=" + account + "&page=" + page + "&number=" + number + "&status=0"

	jsonStr,err := SendRequest(url, prama)

	if err != nil {
		return list,errors.New(err.Error())
	}

	//fmt.Println(jsonStr)

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return list,errors.New(err.Error())
	}

	status,err := jsonData.Get("status").String()

	if err != nil {
		return list,errors.New("Json.Get status:" + err.Error())
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return list,errors.New("Json.Get info:" + info)
	}else{
		data := jsonData.Get("data")
		dataArray,_ := data.Array()
		dataLength := len(dataArray)
		fmt.Println("dataLength",dataLength)
		for i:=0;i<dataLength;i++{
			detail := TransferDetail{}
			indexData := data.GetIndex(i)
			detail.Amount,_ = indexData.Get("amount").String()
			detail.BlockNum,_ = indexData.Get("blockNum").String()
			detail.Error,_ = indexData.Get("error").String()
			detail.Fee,_ = indexData.Get("fee").String()
			detail.Remake,_ = indexData.Get("remark").String()
			detail.Type,_ = indexData.Get("type").String()
			detail.Status,_ = indexData.Get("status").String()
			detail.Txid,_ = indexData.Get("txId").String()
			detail.In,_ = indexData.Get("in").String()
			detail.Out,_ = indexData.Get("out").String()
			detail.Sum,_ = indexData.Get("sum").String()
			detail.Time,_ = indexData.Get("time").String()
			detail.Token,_ = indexData.Get("token").String()
			detail.AuthoritySign,_ = indexData.Get("authority_sign").String()
			list = append(list, detail)
		}
		return list,nil
	}
	return list,nil
}

/**
申请备用节点
 */
func (t *TransferClass) ApplySpareNode(tx TxIdData, from, keyFile, passwd,to,amount,token,nodeStatus string) (int, string, string) {

	//解析钱包json
	keyjson, err := ioutil.ReadFile(keyFile)
	if err != nil {
		return 0, "", "无法解析钱包json"
	}
	//获取私钥
	key, err := keystore.DecryptKey(keyjson, passwd)
	if err != nil {
		return 0, "", "无法获取私钥"
	}

	var status int
	var info string
	status, info = t.doApplySpareNode(from,to,amount,token,nodeStatus, tx, key)

	return status, tx.TxId, info
}

func (t *TransferClass) doApplySpareNode(from,to,amount,token ,nodeStatus string, tx TxIdData, key *keystore.Key) (int, string) {
	msgBody := strings.ToLower(tx.TxId +from)
	msgBody = hex.EncodeToString([]byte( msgBody ))
	fmt.Println("消息",msgBody)
	sign := Sign(msgBody, key)
	fmt.Println("签名",sign)
	url := ServerIp + "/applySpareNode"

	//prama := "lang="+Lang+"&acc=" + from + "&sign=" + sign + "&txid=" + tx.TxId + "&nonce=" + tx.Nonce
	prama := "acc=" + from + "&sign=" + sign + "&txid=" + tx.TxId + "&nonce=" + tx.Nonce+"&amount="+amount+"&nodetype="+nodeStatus


	//prama := "lang=" + lang + "&from=" + from + "&to=" + to + "&amo=" + num + "&fee=" + fee + "&cc=" + token + "&sign=" + sign + "&txid=" + tx.TxId + "&nonce=" + tx.Nonce

	jsonStr, err := SendRequest(url, prama)
	fmt.Println(url)
	fmt.Println(prama)

	fmt.Println("jsonStr:", jsonStr)

	if err != nil {
		return 0, err.Error()
	}

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return 0, "NewJson:" + err.Error()
	}

	status, err := jsonData.Get("status").String()

	if err != nil {
		return 0, "Json.Get status:" + err.Error()
	}

	info, err := jsonData.Get("info").String()

	if err != nil {
		return 0, "Json.Get info:" + err.Error()
	}

	statusInt, err := strconv.Atoi(status)
	if err != nil {
		return 0, "strconv.Atoi status:" + err.Error()
	}
	return statusInt, info
}