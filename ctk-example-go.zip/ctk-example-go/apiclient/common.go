package apiclient

import (
	"strings"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"io"
	"errors"
	"strconv"
	"encoding/json"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"encoding/hex"
	"github.com/ethereum/go-ethereum/crypto"
)


type TxIdData struct{
	TxId string
	Nonce string
}

type TxIdJsonData struct{
	Status string
	Info string
	Data TxIdData
}

/**
获取txid 核 nonce
 */
func GetTxid() (TxIdJsonData,error){
	var js TxIdJsonData

	url := ServerIp + "/crtTx"
	//url := "http://49.73.154.119:8888/crtTx"
	param := "cnt=1"
	client := &http.Client{}
	req, err := http.NewRequest("POST", url, strings.NewReader(param))
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	resp, err := client.Do(req)



	//fmt.Println("txid")
	//fmt.Println("Status Code",resp.StatusCode)
	if err != nil {
		return js,err
	}
	if resp.StatusCode!= 200{
		return js,errors.New("错误码:"+ strconv.Itoa(resp.StatusCode) )
	}

	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return js,errors.New(err.Error())
	}

	jsonStr := string(body)

	//fmt.Println(jsonStr)
	err = json.Unmarshal( []byte(jsonStr) , & js )

	if err != nil {
		return js,errors.New(err.Error())
	}
	return js,nil
}


/**
发送请求到接口
 */
func SendRequest(url string, parama string) (string,error) {

	client := &http.Client{}
	req, err := http.NewRequest("POST", url, strings.NewReader(parama))
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	resp, err := client.Do(req)


	//fmt.Println("Status Code",resp.StatusCode)
	if err != nil {
		return "",err
	}
	if resp.StatusCode!= 200{
		return "",errors.New("错误码:"+ strconv.Itoa(resp.StatusCode) )
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println(err)
	}
	jsonStr := string(body)

	return jsonStr,nil
}

/**
 * 判断文件是否存在  存在返回 true 不存在返回false
 */
func CheckFileIsExist(filename string) bool {
	var exist = true
	if _, err := os.Stat(filename); os.IsNotExist(err) {
		exist = false
	}
	return exist
}


/*
写入内容到文件
 */
 func WriteStringToFile(filename string,wireteString string){
	 var f *os.File
	 var err error
	 if CheckFileIsExist(filename) { //如果文件存在
		 f, err = os.OpenFile(filename, os.O_APPEND, 0666) //打开文件
		 if err != nil{
			 fmt.Println("文件打开失败")
			 return
		 }
	 } else {
		 f, err = os.Create(filename) //创建文件
		 if err != nil{
			 fmt.Println("文件创建失败")
			 return
		 }
	 }
	 defer f.Close()
	 _, err = io.WriteString(f, wireteString) //写入文件(字符串)

 }

//图片转化为16进制
func TranslateImgToHex(filePath string)string {
	imgbyte,err:= ioutil.ReadFile(filePath)
	if err != nil {
		fmt.Println("读取图片失败",err)
		return ""
	}else {
		fmt.Println("图片转化为16进制")
		imghex:= hex.EncodeToString(imgbyte)
		fmt.Println(imghex)
		return imghex
	}
}

//签名
func Sign(str string,key *keystore.Key) string {
	msg := crypto.Keccak256([]byte(str))

	//将消息用私钥进行签名
	sig, err := crypto.Sign(msg, key.PrivateKey)
	if err != nil {
		fmt.Printf("\n sign error: %s",err)
	}
	return hex.EncodeToString( sig[:] )
}
