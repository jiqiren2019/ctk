package apiclient

import (
	"fmt"
	"errors"
	"github.com/bitly/go-simplejson"
)



/**
* 注册账号
* return 错误,账号,keystore
 */
func AddAccount(password string) (string,string,error) {
	//var js AddAccountJsonData

	url := ServerIp +"/acc"
	prama := "cmd=newac&psw=" + password
	jsonStr, err := SendRequest(url, prama)

	var account string
	var keystore string
	if err != nil {
		return account,keystore,errors.New("error1:" + err.Error())
	}

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return account,keystore,err
	}

	fmt.Println(jsonStr)

	status,err := jsonData.Get("status").String()

	if err != nil {
		return account,keystore,errors.New("error2:" + err.Error())
	}

	keystoreBytes,err := jsonData.Get("data").MarshalJSON()
	keystore = string(keystoreBytes)

	if err != nil {
		return account,keystore,err
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return account,keystore,errors.New("error3:" + info)
	}else{
		account,_ = jsonData.Get("info").String()
		return account,keystore,nil
	}
}