package apiclient

import (
	"fmt"
	"errors"
	"strings"
	"encoding/hex"
	"io/ioutil"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"github.com/bitly/go-simplejson"
)

/**
*	token明细信息
 */
type Token struct {
	Name string
	Title string
	Creator string
	Url string
	Total string   		//货币总量
	Decimal string
	Logo string
	Mineral string		//预挖数量
	Award string		//自动挖矿年化率
	Email string		//创始人邮箱
	Date string
}


/**
* 读取token信息
 */
func (t *Token) Find(token string) (*Token,error){

	url := ServerIp +"/tkinfo"
	prama := "cc=" + token
	jsonStr,err := SendRequest(url, prama)

	if err != nil {
		return t,errors.New(err.Error())
	}
	fmt.Println(jsonStr)

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return t,errors.New("error1:" + err.Error())
	}


	status,err := jsonData.Get("status").String()

	if err != nil {
		return t,errors.New("error2:" + err.Error())
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return t,errors.New("error3:" + info)
	}else{
		data := jsonData.Get("data")
		t.Name,_ = data.Get("cc").String()
		t.Title,_ = data.Get("name").String()
		t.Decimal,_ = data.Get("decimal").String()
		t.Total,_ = data.Get("total").String()
		t.Mineral,_ = data.Get("mineral").String()
		t.Mineral = t.Mineral + "%"
		t.Creator,_ = data.Get("creator").String()
		t.Award,_ = data.Get("award").String()
		t.Email,_ = data.Get("email").String()
		t.Logo,_ = data.Get("logo").String()
		t.Logo = ServerIp + "/" +  t.Logo
		t.Date,_ = data.Get("publishTime").String()
		t.Url,_ = data.Get("url").String()
		return t,err
	}
}


/**
*	token明细信息
 */
type TokenMiner struct {
}


/**
收益领取记录
 */
type TokenMinerDetail struct{
	Money string
	Date string
}
/**
	获取挖矿收益列表
 */
 func (*TokenMiner) AwardList(token,account string) ([]TokenMinerDetail,error){
 	var list []TokenMinerDetail
	 url := ServerIp +"/tokenawdlist"
	 prama := "token="+token+"&acc="+account

	 jsonStr,err := SendRequest(url, prama)

	 if err != nil {
		 return list,errors.New(err.Error())
	 }

	 fmt.Println(jsonStr)

	 jsonData, err := simplejson.NewJson([]byte(jsonStr))
	 if err != nil {
		 return list,errors.New("simplejson.NewJson:" + err.Error())
	 }

	 status,err := jsonData.Get("status").String()

	 if err != nil {
		 return list,errors.New("Json.Get status:" + err.Error())
	 }

	 if status == "0"{
		 var info = ""
		 info,_ = jsonData.Get("info").String()
		 return list,errors.New("Json.Get info:" + info)
	 }else {
		 data := jsonData.Get("data")
		 dataArray,_ := data.Array()
		 dataLength := len(dataArray)
		 //fmt.Println("dataLength",dataLength)
		 for i:=0;i<dataLength;i++{
			 detail := TokenMinerDetail{}
			 indexData := data.GetIndex(i)
			 detail.Money,_ = indexData.Get("draw_earnings").String()
			 detail.Date,_ = indexData.Get("draw_time").String()
			 list = append(list, detail)
		 }
		 return list,nil
	 }
 }

/**
	挖矿收益预览
*/
func (*TokenMiner) AwardReview(token,account string) (string,error){

	var award string = ""
	url := ServerIp +"/awardpreview"
	prama := "token="+token+"&acc="+account

	jsonStr,err := SendRequest(url, prama)

	fmt.Println(jsonStr)

	if err != nil {
		return award,err
	}

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return award,errors.New("simplejson.NewJson:" + err.Error())
	}

	status,err := jsonData.Get("status").String()

	if err != nil {
		return award,errors.New("Json.Get status:" + err.Error())
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return award,errors.New("Json.Get info:" + info)
	}else {
		award,_ = jsonData.Get("data").String()
		return award,nil
	}
}

/**
	挖矿收益领取
	return 状态,信息
 */
func (*TokenMiner) AwardGet(token,account,keyFile,passwd string) (int,string) {
	url := ServerIp +"/award"

	//解析钱包json
	keyjson, err := ioutil.ReadFile(keyFile)
	if err != nil {
		return 0,err.Error()
	}
	//获取私钥
	key, err := keystore.DecryptKey(keyjson, passwd)
	if err != nil {
		if err.Error() == "could not decrypt key with given passphrase"{
			return 0,"密码错误"
		}else{
			return 0,err.Error()
		}
	}

	txData,err := GetTxid() ; if err != nil{
		return 0,err.Error()
	}


	msgBody :=  strings.ToLower(txData.Data.TxId + token +  account)
	msgBody = hex.EncodeToString([]byte( msgBody ))
	sign := Sign(msgBody,key)

	prama := "txid="+txData.Data.TxId+"&nonce="+txData.Data.Nonce+"&acc="+account +"&cc=" + token + "&sign=" + sign

	jsonStr,err := SendRequest(url, prama)

	if err != nil {
		return 0,err.Error()
	}

	fmt.Println(jsonStr)

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return 0,"simplejson.NewJson:" + err.Error()
	}

	status,err := jsonData.Get("status").String()

	if err != nil {
		return 0,"Json.Get status:" + err.Error()
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return 0,info
	}else {
		return 1,"success"
	}
}


