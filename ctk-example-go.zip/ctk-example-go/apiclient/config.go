package apiclient

var ServerIp = "https://n1.ctk.bz" //CTK接口服务