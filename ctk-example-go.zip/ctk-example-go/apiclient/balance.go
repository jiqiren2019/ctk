package apiclient

import (
	"fmt"
	"errors"
	"github.com/bitly/go-simplejson"
)


/**
* 批量查询账号余额
* return 数组
 */
func BatBalance(tokenName []string,account []string) (map[string]string,error){
	//var balance []string
	keylist := make(map[string]string)
	url :=  ServerIp + "/bal?arg={\"cclist\":["
	prama := ""
	for i:=0;i<len(tokenName);i++{
		_token := tokenName[i]
		_acc := account[i]
		if i>0{
			prama += ","
		}
		prama += "{\"cc\":\"" + _token + "\",\"addr\":\"" + _acc + "\"}"
		keylist[ _token + "_" + _acc ] = ""
	}
	url = url + prama + "]}"
	jsonStr,_ := SendRequest(url, prama)

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return keylist,errors.New("error1:" + err.Error())
	}

	fmt.Println(jsonStr)

	status,err := jsonData.Get("status").String()

	if err != nil {
		return keylist,errors.New("error2:" + err.Error())
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return keylist,errors.New("error3:" + info)
	}else{
		data := jsonData.Get("data")
		for k,_ := range keylist{
			keylist[k],_ = data.Get(k).String()
		}
		return keylist,err
	}
}


/**
* 查询账号余额
* return 余额,错误
 */
func Balance(tokenName string,account string) (string,error){
	var balance = ""

	url :=  ServerIp + "/qry"
	prama := "cmd=qryBal&cc="+tokenName+"&args=" + account
	jsonStr,err := SendRequest(url, prama)

	if err != nil {
		return balance,errors.New(err.Error())
	}

	jsonData, err := simplejson.NewJson([]byte(jsonStr))
	if err != nil {
		return balance,errors.New("error1:" + err.Error())
	}

	fmt.Println(jsonStr)

	status,err := jsonData.Get("status").String()

	if err != nil {
		return balance,errors.New("error2:" + err.Error())
	}

	data := jsonData.Get("data")

	balance,err = data.Get(tokenName).String()

	if err != nil {
		return balance,errors.New("error3:" + err.Error())
	}

	if status == "0"{
		var info = ""
		info,_ = jsonData.Get("info").String()
		return balance,errors.New("error4:" + info)
	}else{
		return balance,err
	}
}