Start the method:

chmod u+x node

./node